﻿/* 1. 플레이어 클래스만 사용
 * 2. 플레이어와 몬스터 전투 구현
 * 3. 
 * 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TextRPG;

namespace ResetRPG
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TextRPGMain();
        }

        static void TextRPGMain()
        {
            Player player;
            Player monster;

            player = new Player("player", 10, 30);
            monster = new Player("slime",10,30);

            monster.SetItemSlot(new Item("힐링포션(소)", 10));

            while (true)
            {
                //string strInput;

                //Console.WriteLine("행독을 선택하세요!");
                //strInput = Console.ReadLine();
                //if (strInput == "공격")
                {
                    player.Display("가 공격했다!");
                    player.Attack(monster);
                }
                //else
                {
                    player.UseItemSlot();
                    player.Display("가 아이템을 사용했다!");
                }
                monster.Display("이 피해를 입었다!");
                if (monster.Death())
                {
                    monster.Display("이 패배했다.");
                    Item item = monster.ReleaseItem();
                    player.SetItemSlot(item);
                    player.Display("가 아이템을 획득했다!");
                    break;
                }

                monster.Display("이 공격했다!");
                monster.Attack(player);
                player.Display("가 피해를 입었다!");
                if (player.Death())
                {
                    player.Display("가 패배했다.");
                    break;
                }
            }
        }
    }
}
